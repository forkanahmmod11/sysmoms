import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { createClient, type Session, type User } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = supabaseUrl && supabaseAnonKey
  ? createClient(supabaseUrl, supabaseAnonKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } })
  : null;

export type Role =
  | 'super_admin' | 'admin' | 'moderator'
  | 'full_stack_developer' | 'backend_developer' | 'frontend_developer'
  | 'graphics_video_editor' | 'marketing_specialist' | 'hr' | 'employee';

export const ROLE_LABELS: Record<Role, string> = {
  super_admin: 'Super Admin',
  admin: 'Admin',
  moderator: 'Moderator',
  full_stack_developer: 'Full-Stack Developer',
  backend_developer: 'Backend Developer',
  frontend_developer: 'Frontend Developer',
  graphics_video_editor: 'Graphics & Video Editor',
  marketing_specialist: 'Marketing Specialist',
  hr: 'HR',
  employee: 'Employee',
};

export type Organization = {
  id: string;
  name: string;
  subdomain: string | null;
  status: string;
};

export type UserProfile = {
  id: string;
  email: string;
  fullName: string;
  avatarUrl: string | null;
  role: Role;
  organization: Organization | null;
  // OMS-compatible profile fields
  full_name: string | null;
  avatar_url: string | null;
  cover_url: string | null;
  bio: string | null;
  skills: string[];
  certifications: string[];
  achievements: string[];
  experience: Array<{ id?: string; title: string; company: string; startDate: string; endDate: string | null; description: string }>;
  phone: string | null;
  address: string | null;
  position: string | null;
  department_id: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

const ADMIN_EMAILS = ['ahmedforkan26@gmail.com', 'forkanahmmod@gmail.com', 'admin@sysmobyte.com'];

function getAuthErrorMessage(message: string): string {
  const normalized = message.toLowerCase();
  if (normalized.includes('failed to fetch') || normalized.includes('networkerror')) {
    return 'Cannot connect to the account server. Please check your internet connection, then try again.';
  }
  if (normalized.includes('security purposes') && normalized.includes('4 seconds')) {
    return 'Please wait a few seconds before trying to create the account again.';
  }
  if (normalized.includes('email rate limit exceeded') || normalized.includes('email rate limit')) {
    return 'Too many signup emails were requested recently. Wait a few minutes before trying again, or configure a production SMTP provider in Supabase Auth.';
  }
  if (normalized.includes('email not confirmed')) {
    return 'Email not confirmed. Confirm your email, then sign in to open your workspace.';
  }
  return message;
}

export function isAdminEmail(email: string): boolean {
  return ADMIN_EMAILS.includes(email.trim().toLowerCase());
}

type AuthContextValue = {
  session: Session | null;
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  refreshProfile: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<{ error: string | null }>;
  signUpWithEmail: (email: string, password: string) => Promise<{ error: string | null }>;
  signInWithGoogle: () => Promise<{ error: string | null }>;
  offlineAccess: boolean;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

async function loadProfile(userId: string, userEmail: string | undefined): Promise<UserProfile> {
  if (!supabase) {
    return { id: userId, email: userEmail || '', fullName: 'Guest', avatarUrl: null, role: 'employee', organization: null,
      full_name: 'Guest', avatar_url: null, cover_url: null, bio: null, skills: [], certifications: [], achievements: [], experience: [],
      phone: null, address: null, position: null, department_id: null, is_active: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() };
  }
  const { data: profile } = await supabase
    .from('profiles')
    .select('id, email, full_name, avatar_url, cover_url, role, organization_id, organizations(id, name, subdomain, status)')
    .eq('id', userId)
    .maybeSingle();

  const meta = (await supabase.auth.getUser()).data.user?.user_metadata || {};
  const orgData = (profile as Record<string, unknown> | null)?.organizations as Organization | null | undefined;

  return {
    id: userId,
    email: profile?.email || userEmail || '',
    fullName: profile?.full_name || meta.full_name || meta.name || (userEmail ? userEmail.split('@')[0] : 'User'),
    avatarUrl: profile?.avatar_url || meta.avatar_url || meta.picture || null,
    full_name: profile?.full_name || meta.full_name || meta.name || (userEmail ? userEmail.split('@')[0] : 'User'),
    avatar_url: profile?.avatar_url || meta.avatar_url || meta.picture || null,
    cover_url: profile?.cover_url || null,
    bio: profile?.bio || null,
    skills: profile?.skills || [],
    certifications: profile?.certifications || [],
    achievements: profile?.achievements || [],
    experience: profile?.experience || [],
    phone: profile?.phone || null,
    address: profile?.address || null,
    position: profile?.position || null,
    department_id: profile?.department_id || null,
    is_active: profile?.status !== 'offline',
    created_at: profile?.created_at || new Date().toISOString(),
    updated_at: profile?.updated_at || new Date().toISOString(),
    // Keep the application role in sync with the designated platform admins.
    // Existing profiles may still contain `admin` from an older migration, so
    // the email check must take precedence when an admin signs in.
    role: userEmail && isAdminEmail(userEmail)
      ? 'super_admin'
      : ((profile?.role as Role) || 'employee'),
    organization: orgData || null,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [offlineAccess, setOfflineAccess] = useState(false);
  const [loading, setLoading] = useState(true);

  const refreshProfile = async () => {
    if (!user) { setProfile(null); return; }
    const p = await loadProfile(user.id, user.email);
    setProfile(p);
  };

  useEffect(() => {
    if (!supabase) { setLoading(false); return; }

    let settled = false;

    const { data: sub } = supabase.auth.onAuthStateChange((_event, newSession) => {
      (async () => {
        setSession(newSession);
        setUser(newSession?.user ?? null);
        if (newSession?.user) {
          const p = await loadProfile(newSession.user.id, newSession.user.email);
          setProfile(p);
        } else {
          setProfile(null);
        }
        if (!settled) { settled = true; setLoading(false); }
      })();
    });

    (async () => {
      const { data, error } = await supabase.auth.getSession();
      if (!error && data.session) {
        setSession(data.session);
        setUser(data.session.user);
        const p = await loadProfile(data.session.user.id, data.session.user.email);
        setProfile(p);
      }
      if (!settled) { settled = true; setLoading(false); }
    })();

    return () => { sub.subscription.unsubscribe(); };
  }, []);

  const signInWithEmail = async (email: string, password: string) => {
    if (!supabase) return { error: 'The workspace connection is not configured.' };
    const normalizedEmail = email.trim().toLowerCase();

    try {
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: normalizedEmail,
        password,
      });
      if (signInError) return { error: getAuthErrorMessage(signInError.message) };
      if (data.user && !data.user.email_confirmed_at && data.user.app_metadata?.provider === 'email') {
        await supabase.auth.signOut();
        return { error: 'Please verify your email address from the verification email before signing in.' };
      }
      if (data.user && data.session) {
        const p = await loadProfile(data.user.id, data.user.email);
        setProfile(p);
      }
      return { error: null };
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unable to reach the workspace service.';
      return { error: getAuthErrorMessage(message) };
    }
  };

  const signUpWithEmail = async (email: string, password: string) => {
    if (!supabase) return { error: 'The workspace connection is not configured.' };
    const normalizedEmail = email.trim().toLowerCase();
    try {
      const { data, error: signUpError } = await supabase.auth.signUp({
        email: normalizedEmail,
        password,
        options: {
          data: { full_name: normalizedEmail.split('@')[0] },
          emailRedirectTo: window.location.origin,
        },
      });
      if (signUpError) return { error: getAuthErrorMessage(signUpError.message) };
      if (data.user) {
        const p = await loadProfile(data.user.id, data.user.email);
        setProfile(p);
      }
      return { error: null };
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unable to reach the workspace service.';
      return { error: getAuthErrorMessage(message) };
    }
  };

  const signInWithGoogle = async () => {
    if (!supabase) return { error: null };
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: window.location.origin },
    });
    return { error: error?.message ?? null };
  };

  const signOut = async () => {
    if (!supabase) return;
    await supabase.auth.signOut();
    setSession(null);
    setUser(null);
    setProfile(null);
    setOfflineAccess(false);
  };

  return (
    <AuthContext.Provider value={{ session, user, profile, loading, refreshProfile, signInWithEmail, signUpWithEmail, signInWithGoogle, offlineAccess, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
